<?php
namespace Controllers ;

use Silex\Application;
use Silex\ControllerProviderInterface;
use Symfony\Component\HttpFoundation\Request;

class LobbyControllerProvider implements ControllerProviderInterface
{
    private $entityManager ;
    
    public function connect(Application $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];
        $this->entityManager = $app['orm.em'] ;
        
        /*
         * List existing games
         */
        $controllers->get('/List', function(Request $request) use ($app)
        {
            return $app['twig']->render('Lobby/List.twig', array(
               'layout_template' => 'layout.twig' ,
               'list' => $this->getGamesList() ,
               'is_admin' => in_array('ROLE_ADMIN', $app['user']->getRoles()) ,
            ));
        })
        ->bind('ListGames');
        
        return $controllers ;
    }
    
    public function getGamesList()
    {
        $query = $this->entityManager->createQuery('SELECT g , p FROM Entities\Game g LEFT JOIN g.parties p');
        $result = $query->getArrayResult() ;
        return $result ;
    }

}